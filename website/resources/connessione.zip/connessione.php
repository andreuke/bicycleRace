<?php

$password = "";
$user = "root";
$db_database = "divvydb";

$connessione = mysql_connect("localhost", $user, $password)
    or die("Connection Failed: " . mysql_error());
mysql_select_db($db_database, $connessione);

?>